                    INSTALLING AUDIO DRIVERS IN WINDOWS NT 
                    ======================================

This package is to be used ONLY with Intel and Intel-compatible x86 PC systems.

NOTE: Please refer to your Getting Started manual if you need instructions on 
physically installing your Creative audio card into the system.

This README file provides instructions on installing Creative audio drivers 
into Windows NT 4.0 for the following types of system configurations:

   A> Installing Creative Plug and Play (PnP) audio cards on
      systems with no Creative audio drivers installed

   B> Installing Creative Plug and Play (PnP) audio cards on
      systems with old Creative audio drivers installed

   C> Installing Creative Legacy audio cards

   D> Installing AWE Control Panel (for SB32/AWE32/AWE64/AWE64G only)

To properly select the best section of installation steps to follow, use 
these guidelines:

   1) Open the Multimedia applet.  This can be done by clicking on Start, 
      Settings, Control Panel, and then double-clicking Multimedia.

   2) Click the Devices tab of the Multimedia applet, and double-click 
      the Audio devices line.

   3) If one or more of the following devices are installed:

      Audio for Creative Labs Sound Blaster 1.X, PRO, 16
      Audio for Creative Sound Blaster 16 or AWE32
      Audio for Sound Blaster 16

      Then you will need to remove your current audio drivers before 
      continuing.  After removing the drivers follow the instructions in 
      Section C, Installing Creative Legacy audio cards.

   4) If the device installed states the following:

      Creative Labs Sound Blaster 16 PnP

      Follow the instructions in Section B, Installing Creative Plug and 
      Play (PnP) audio cards on systems with old Creative audio drivers installed.

   5) If a message box appears and states the following:

      There are no devices of this class installed in your system

      Follow the instructions in Section A, Installing Creative Plug and Play (PnP) 
      audio cards on systems with no Creative audio drivers installed.


======================================================================
A.     INSTALLING CREATIVE PLUG AND PLAY (PNP) AUDIO CARDS ON
       SYSTEMS WITH NO CREATIVE AUDIO DRIVERS INSTALLED
======================================================================

       1. Switch on your computer and log on as an Administrator.
	  
       2. If the New Hardware Found message box appears, skip to
          Step 4 to install the Creative Audio Drivers.
          Otherwise, it means that the PNPISA.INF driver has not
          been installed in your system.  Proceed to Step 3 to
          install it:


       3. INSTALLING PNPISA.INF
          ---------------------

          3.1 Insert the Windows NT 4.0 CD-ROM into the CD-ROM drive.
          
          3.2 Start Windows NT Explorer and look for a file called
              PNPISA.INF in E:\DRVLIB\PNPISA\X86
              (where E: represents the CD-ROM drive).
         
          3.3 If you cannot find this file, do the following steps:
              a) On the View menu of the Windows NT Explorer, click
                 Options.
              b) On the View tabbed page, select the Show All Files
                 option and clear the Hide Extensions For Known File
                 Types check box.
              c) Click the OK button.

          3.4 Locate the file PNPISA.INF (see step 3.2).  Right-click
              this file, select Install and follow the on-screen
              instructions.
       
          3.5 Restart your computer when prompted.


       4. INSTALLING CREATIVE AUDIO DRIVERS
          ---------------------------------

          4.1 The New Hardware Found message boxes for the various
              devices will appear.

          4.2 When prompted to insert disks, click the Cancel button.

          4.3 On the taskbar in the Windows NT Desktop, click the
              Start button and select Run.

          4.4 If your are installing from the Drivers Disk, type
                 A:\UPDPNPNT.EXE
              where A: represents the floppy drive.
              Note: Leave the disk in the floppy drive as it will
                    still be used in this installation.

              If the driver files are in your hard disk, type in the 
              path of the file:
                 e.g. C:\NTFOLDER\UPDPNPNT.EXE
              where C: represents your hard disk drive and NTFOLDER is
              the name of the folder where you placed the driver files.
              
          4.5 Click the OK button.
              When the Warning dialog box appears, click the OK
              button. A series of Configuration dialog boxes will
              appear.

          4.6 If the Resource Settings are given, and there are no
              conflicts in the Conflicting Device list box, click the
              OK button.

              If the Resource Settings are not given, click the Set 
              Configuration Manually button and accept the given
              settings.

              If there are conflicts in the Conflicting Device List
              Box, follow the instructions in Step 5.
          
          4.7 If you are prompted for the Windows NT CD-ROM, it means
              that the program is trying to install the Joystick port
              enabler. Proceed with the following steps. Otherwise
              skip to step 4.8.
              a) Insert the Windows NT 4.0 CD-ROM into the drive and
                 click the OK button. 
              b) At the Files Needed dialog box, type
                    E:\DRVLIB\AUDIO\SBPNP\i386
                 and click the OK button.
             
          4.8 Repeat Step 4.6 for all configuration boxes that appear.

          4.9 Remove the disk, if any, from the floppy drive.

          4.10 Restart the computer when prompted.


       5. RESOLVING CONFLICTS
          -------------------

          If there are conflicts in the Conflicting Device List box of
          any Configuration dialog box, proceed with the following
          steps.
              
          5.1 In the Setting Based On text box, click
              Basic Configuration 0001.

          5.2 Select the setting that you want to change in the
              Resource Settings list box and click the Change Setting
              button.

          5.3 Choose a setting value that does not conflict with
              another device and click the OK button.

          5.4 Repeat steps 5.1 to 5.3 for any other settings that
              show a conflict.

          5.5 Click the OK button. A Creating A Forced Configuration
              dialog box will appear.

          5.6 Click the Yes button.


      6.  CHECKING THE INSTALLATION
          -------------------------
          Your Sound Blaster card should be working properly at this
          point.
           
          If you need to change the resources used by your card, do
          the following steps:
          a) On the taskbar in the Windows NT Desktop, click the Start
             button select Settings followed by Control Panel.
          b) Double-click the Multimedia icon and click the Devices
             tabbed page.
          c) Double-click Audio Devices to expand the list.
          d) Select the Creative Sound Blaster and click the
             Properties button.
          e) Click the Settings button.  The Configuration dialog box
             appears.
          f) To make changes, follow the instructions described above. 
 


======================================================================
B.     INSTALLING CREATIVE PLUG AND PLAY (PNP) AUDIO CARDS ON
       SYSTEMS WITH OLD CREATIVE AUDIO DRIVERS INSTALLED
======================================================================

       1. Switch on your computer and log on as an Administrator.

       2. REMOVING EXISTING CREATIVE AUDIO DRIVERS
          ----------------------------------------
       
          2.1 On the taskbar in the Windows NT desktop, click the
              Start button and select Run.

          2.2 If you are installing from the Drivers Disk, type 
                 A:\UPDPNPNT.EXE
              where A: represents the floppy drive.

              If the driver files are in your hard disk, type in the 
              path of the file:
                 e.g. C:\NTFOLDER\UPDPNPNT.EXE
              where C: represents your hard disk drive and NTFOLDER is
              the name of the folder where you placed the driver files.

          2.3 Click the OK button. A Warning dialog box will appear.

          2.4 Click the OK button. A series of Driver Present dialog
              boxes will appear.

          2.5 Click the Yes button to remove the existing drivers.

          2.6 Remove the disk, if any, from the floppy drive.

          2.7 Restart the computer when prompted.

       3. INSTALLING NEW CREATIVE AUDIO DRIVERS
          -------------------------------------
          You will see a series of New Hardware Found message boxes.

          3.1 When the Insert Disk dialog box appears, click the OK
              button.
              
          3.2 At the Files Needed dialog box, 

              If you are installing from the Drivers Disk, type 
                 A:\
              where A: represents the floppy drive.

              If the driver files are in your hard disk, type in the 
              path of the folder:
                 e.g. C:\NTFOLDER\
              where C: represents your hard disk drive and NTFOLDER is
              the name of the folder where you placed the driver files.

          3.3 Click the OK button. A Configuration dialog box will
              appear.

          3.4 If the Resource Settings are given, and there are no
              conflicts in the Conflicting Device List box, click the
              OK button.

              If the Resource Settings are not given, click the Set
              Configuration Manually button and accept the given
              settings.

              If there are conflicts in the Conflicting Device List
              box, follow the instructions in Step 4.

          3.5 Repeat Steps 3.1 to 3.4 for all the Insert Disk dialog
              boxes that appear for each of the drivers.
 
          3.6 Remove the disk, if any, from the floppy drive.

          3.7 Restart the computer when prompted.


       4. RESOLVING CONFLICTS
          -------------------

          If there are conflicts in the Conflicting Device List box of
          any Configuration dialog box, proceed with the following
          steps.
              
          4.1 In the Setting Based On text box, click
              Basic Configuration 0001.

          4.2 Select the setting that you want to change in the
              Resource Settings list box and click the Change
              Setting button.

          4.3 Choose a setting value that does not conflict with
              another device and click the OK button.

          4.4 Repeat steps 4.1 to 4.3 for any other settings that show
              a conflict.

          4.5 Click the OK button. A Creating A Forced Configuration
              dialog box will appear.

          4.6 Click the Yes button.

 
       5. CHECKING THE INSTALLATION
          -------------------------
          Your Sound Blaster card should be working properly at this
          point.
           
          If you need to change the resources used by your card, do
          the following steps:
          a) On the taskbar in the Windows NT Desktop, click the Start
             button select Settings followed by Control Panel.
          b) Double-click the Multimedia icon and click the Devices
             tabbed page.
          c) Double-click Audio Devices to expand the list.
          d) Select the Creative Sound Blaster and click the
             Properties button.
          e) Click the Settings button.  The Configuration dialog box
             appears.
          f) To make changes, follow the instructions described above.



======================================================================
C.     INSTALLING CREATIVE LEGACY AUDIO CARDS
======================================================================
    
       1. Log on to your computer as an Administrator.

       2. On the taskbar in the Windows NT Desktop, click the Start 
          button, select Settings, and click Control Panel.

       3. Double-click the Multimedia icon.

       4. On the Devices tabbed page, remove entries with the term 
          "Creative" under Audio Devices and MIDI Devices and Instruments.
          These are the previously installed Sound Blaster drivers.

       5. Click the Add button.

       6. From the List Of Drivers box on the Add dialog box,
          click Unlisted Or Updated Driver, and click the OK button.

       7. In the Install Driver dialog box,

          If you are installing from the Drivers Disk, type 
              A:\
          where A: represents the floppy drive.

          If the driver files are in your hard disk, type in the 
          path of the file:
             e.g. C:\NTFOLDER\
          where C: represents your hard disk drive and NTFOLDER is
          the name of the folder where you placed the driver files.

       8. In the Add Unlisted Or Updated Driver dialog box,
          click Creative Sound Blaster 16, and click the OK button.

       9. Click the New button.

      10. When prompted, select the Sound Blaster hardware
          settings such as base I/O address, DMA, IRQ and MPU-401
          port settings.

          All the .SYS files will be copied into the
          C:\WINNT\SYSTEM32\DRIVERS directory. The .ACV and .DLL
          files will be copied into the C:\WINNT\SYSTEM32 directory.
	   
      11. You will be prompted to restart your computer.

             * If your card is an SB16, click the Restart Now button.
               Your installation ends here.

             * If your card is an AWE32 or a SB32 card,
               click the Don't Restart Now button.

      12. Repeat steps 5 to 7.

      13. In the Add Unlisted Or Updated Driver dialog box, 
          click Creative Sound Blaster AWE32 MIDI Synth,
          and click the OK button.

      14. Repeat steps 9 to 10.

      15. You will be prompted to restart your computer.  Click the 
          Restart Now button.  Your installation is now complete.
   


======================================================================
D.     INSTALLING AWE CONTROL PANEL (FOR SB32/AWE32/AWE64/AWE64G ONLY)
======================================================================

       1. Create a directory in your system. You can use a directory
          name of your choice, e.g. c:\awe32cp

       2. Copy the following files into the directory you have created:
          - AWECP32.EXE      AWE Control Panel application.
          - AWECP.HLP        AWE Control Panel help file.
          - AWECP.CNT        AWE Control Panel help contents page.
          - AWE32RES.DLL     AWE resource DLL.
          - CTRES32.DLL      Creative resource DLL

       3. Copy the following files into the C:\WINNT\SYSTEM32\
          directory:
          - AWEMAN.DLL
          - AWEMAN32.DLL

       4. If you wish to create a shortcut for the AWE Control Panel:

          a) Right-click at an empty space on the desktop.

          b) Select New and click Shortcut.

          c) On the Create Shortcut dialog box, click the Browse
             button.

          d) Go to directory that you have created for the AWE Control
             Panel and select AWECP32.EXE.

          e) Click the Next button.

          f) Click the Finish button.

          The shortcut to the AWE Control Panel will be created on your
          desktop.

      

     ******************** End  of  ReadMe  file ********************
